/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import com.toedter.calendar.JDateChooser;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Contrato;
import modelDAO.ContratoDAO;
import views.ViewsContrato.TelaAtualizarContratoVIEW;
import views.ViewsContrato.TelaContratoVIEW;
import views.ViewsContrato.TelaExcluirContratoVIEW;
import views.ViewsEmpresa.TelaCadastrarFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerAtualizarContrato extends MouseAdapter{
    TelaAtualizarContratoVIEW TAC = new TelaAtualizarContratoVIEW();
    TelaContratoVIEW TC = new TelaContratoVIEW();
    
    TelaExcluirContratoVIEW TEC = new TelaExcluirContratoVIEW();
    ContratoDAO cDAO = new ContratoDAO();
    Contrato contrato1 = new Contrato();

   public ControllerAtualizarContrato(TelaAtualizarContratoVIEW TELAATUALIZARCONTRATO) {
          TAC = TELAATUALIZARCONTRATO;
          this.TAC.Panel_Atualizar.addMouseListener(this);
          this.TAC.Panel_Voltar.addMouseListener(this);
          this.TAC.Panel_excluir.addMouseListener(this);
          this.TAC.label_lupa.addMouseListener(this);
        //  this.TAC.djDiaInicial = new JDateChooser();
        //  this.TAC.djDiaFinal = new JDateChooser();
   }

    @Override
    public void mouseClicked(MouseEvent e) {
        //QUATRO BOTÕES: UM PARA PESQUISAR, ATUALIZAR,VOLTAR E PARA ABRIR TELA DE EXCLUSÃO DE CONTRATOS
        
        
        
        //Variáveis 
        
        String HorarioInicial,HorarioFinal,Localizacao,Tipo,Clausula,Status,Cpf,Cnpj;
        
        String IdContrato;
        
        //Inicializando as variáveis 

        HorarioFinal = TAC.ftHoraFinal.getText();
        HorarioInicial= TAC.ftHoraInicial.getText();
        Localizacao = TAC.txtLocal.getText();
        Tipo = TAC.cb_tipo.getSelectedItem().toString();
        Clausula = TAC.txtClausula.getText();
        Status = TAC.cbStatus.getSelectedItem().toString();
        IdContrato = TAC.txtIdContrato.getText();
        Cpf = TAC.ftCPF.getText();
        Cnpj = TAC.ftCNPJ.getText();
        
        
        //String dataIni =  TC.djDiaInicial.getDateEditor().getUiComponent()).getText();
        //String dataFin = (((JTextField) TC.djDiaFinal.getDateEditor().getUiComponent()).getText());
        //Colocando dentro do Contrato
        //java.sql.Date dini = new  java.sql.Date
        
       // TC.djDiaInicial.setDate(date1);
        contrato1.setDiaincial((((JTextField) TC.djDiaInicial.getDateEditor().getUiComponent()).getText()));
        contrato1.setDiafinal((((JTextField) TC.djDiaFinal.getDateEditor().getUiComponent()).getText()));
        contrato1.setHorarioinicial(HorarioInicial);
        contrato1.setHorariofinal(HorarioFinal);
        contrato1.setLocalizacao(Localizacao);
        contrato1.setTipo(Tipo);
        contrato1.setClausula(Clausula);
        contrato1.setStatus(Status);
        contrato1.setId(IdContrato);
        contrato1.setCnpj_Empresa(Cnpj);
        contrato1.setCpf_Funcionario(Cpf);
      //  contrato1.setDiaincial(dia);
        
        //Preenchendo os campos pela pesquisa de
        if(e.getSource()==this.TAC.label_lupa){
            if(TAC.txtIdContrato != null){
                preencheCamposContrato(TAC);
               preencheData(TAC.tb_datas);
                
            }else {
           
            JOptionPane.showMessageDialog(null,"Esse contrato não consta");
            
        }   
      }    
        
        
        //CASO ELE CLIQUE EM ATUALIZAR ELE CHAMA A FUNÇÃO ATUALIZAR do DAO
        if(e.getSource()==this.TAC.Panel_Atualizar){
               if(TAC.txtIdContrato != null){
                   String dInicial  = ((JTextField)TAC.djDiaInicial.getDateEditor().getUiComponent()).getText();
                   String dFinal  = ((JTextField)TAC.djDiaFinal.getDateEditor().getUiComponent()).getText();
                   cDAO.atualizarContrato(IdContrato, contrato1, dInicial ,dFinal);
                   JOptionPane.showMessageDialog(null, " Foi atualizado com sucesso"); 
               }else {
            
        
                JOptionPane.showMessageDialog(null,"Não foi atualizado");
                 }
        }
     
        //ELE VOLTA PARA TELA DE CADASTRARCONTRATO
        if(e.getSource()==this.TAC.Panel_Voltar){
            this.TC.setVisible(true);
            this.TAC.dispose();
            ControllerCadastrarContrato CCC = new ControllerCadastrarContrato(TC);
        } 
            
       //EKE VAI PARA TELA DE EXCLUIRCONTRATO 
       if(e.getSource()==this.TAC.Panel_excluir){
            this.TEC.setVisible(true);
            this.TAC.dispose();
            ControllerExcluirContrato CEC = new ControllerExcluirContrato(TEC);
            
        }
           


    }

    //Preenchendo o campo a partir da pesquisa
     public void preencheCamposContrato(TelaAtualizarContratoVIEW TAC) {
        Contrato contrato = cDAO.pesquisarContratosporIdIndividual(contrato1);
        TAC.txtIdContrato.setText(contrato.getId());
        TAC.ftCPF.setText(contrato.getCpf_Funcionario());
        TAC.ftCNPJ.setText(contrato.getCnpj_Empresa());
        TAC.ftHoraInicial.setText(contrato.getHorarioinicial());
        TAC.ftHoraFinal.setText(contrato.getHorariofinal());
        TAC.txtLocal.setText(contrato.getLocalizacao());
        TAC.cb_tipo.setSelectedItem(contrato.getTipo());
        TAC.cbStatus.setSelectedItem(contrato.getStatus());
        TAC.txtClausula.setText(contrato.getClausula());
       // TAC.djDiaInicial.setDateFormatString(contrato.getDiaincial());
       // TAC.djDiaFinal.setDateFormatString(contrato.getDiafinal());
        
    }
   
   
     public void preencheData(JTable tabela){
         Contrato c = cDAO.listarData(contrato1);
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);
        
        tabelado.addColumn("DIA INICIAL");
        tabelado.addColumn("DIA FINAL");
        
        Object[] coluna = new Object[2];
         
        coluna[0] = c.getDiaincial();
        coluna[1] = c.getDiafinal();
         tabelado.addRow(coluna);
         tabela.setModel(tabelado);
     }
   
    
}
