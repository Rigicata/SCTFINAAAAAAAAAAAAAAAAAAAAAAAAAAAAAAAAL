/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import model.Empresa;
import modelDAO.EmpresaDAO;
import views.ViewsEmpresa.TelaAtualizarEmpresaVIEW;
import views.ViewsEmpresa.TelaAtualizarSenhaEmpresaVIEW;
import views.ViewsEmpresa.TelaConsultarFuncionarioVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;

/**
 *
 * @author wesle
 */
public class ControllerTelaAtualizarEmpresa extends MouseAdapter {

    TelaAtualizarEmpresaVIEW TAE = new TelaAtualizarEmpresaVIEW();
    EmpresaDAO eDAO = new EmpresaDAO();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    TelaAtualizarSenhaEmpresaVIEW TASE = new TelaAtualizarSenhaEmpresaVIEW();
    Empresa empresa = new Empresa();
  
    
    
    
    

    public ControllerTelaAtualizarEmpresa(TelaAtualizarEmpresaVIEW TELAATUALIZAREMPRESA) {
        this.TAE = TELAATUALIZAREMPRESA;
        this.TAE.Panel_Atualizar.addMouseListener(this);
        this.TAE.Panel_Senha.addMouseListener(this);
        this.TAE.Panel_Voltar.addMouseListener(this);
        this.TAE.Label_Pesquisar.addMouseListener(this);

    }

   
   
    
    
    public void mouseClicked(MouseEvent e) {
        //Verificação para Pesquisar pelo CNPJ
       // Empresa champreenche = preencheCamposEmpresa(TAE);
       String nome,nomeFantasia,endereco,bairro,complemento,numerorua,cep,cidade,estado,celular,telefone,email,ramo;
       
       String cnpj =  TAE.ftCNPJ.getText();
       nome = TAE.txtNomeEmpresa.getText();
       nomeFantasia = TAE.txtNomeFantasia.getText();
       endereco = TAE.txtEndereco.getText();
       bairro = TAE.txtBairro.getText();
       complemento = TAE.txtComplemento.getText();
       numerorua = TAE.txtNumeroRua.getText();
       cep = TAE.ftCep.getText();
       cidade = TAE.txtCidade.getText();
       estado = TAE.txtEstado.getText();
       celular = TAE.ftCelular.getText();
       telefone = TAE.txtEmail.getText();
       ramo = TAE.txtRamoEmpresa.getText();
       email = TAE.txtEmail.getText();
       empresa.setEmail(email);
       empresa.setCnpj(cnpj);
       empresa.setNome(nome);
       empresa.setNomefantasia(nomeFantasia);
       empresa.setEstado(estado);
       empresa.setEndereco(endereco);
       empresa.setBairro(bairro);
       empresa.setComplemento(complemento);
       empresa.setNumero(numerorua);
       empresa.setCep(cep);
       empresa.setCidade(cidade);
       empresa.setCelular(celular);
       empresa.setTelefone(telefone);
       empresa.setRamoempresa(ramo);
      
      
       //Pesquisar o CNPJ para listar na tela
        if (e.getSource() == TAE.Label_Pesquisar) {
               
                preencheCamposEmpresa(TAE);
            
        }
            
              
       //AO ATUALIZAR
       if (e.getSource() == TAE.Panel_Atualizar) {
           
           if(TAE.txtNomeEmpresa.getText().isEmpty() || TAE.txtNomeFantasia.getText().isEmpty() || TAE.txtBairro.getText().isEmpty() || TAE.txtCidade.getText().isEmpty() || TAE.txtComplemento.getText().isEmpty() || TAE.txtEmail.getText().isEmpty() || TAE.txtEndereco.getText().isEmpty() || TAE.txtEstado.getText().isEmpty() || TAE.txtNomeEmpresa.getText().isEmpty() || TAE.txtNumeroRua.getText().isEmpty() || TAE.txtRamoEmpresa.getText().isEmpty() || TAE.ftCNPJ.getText().isEmpty() || TAE.ftCelular.getText().isEmpty() || TAE.ftCep.getText().isEmpty() || TAE.ftTelefoneFixo.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Campo em branco");
           }else{
                eDAO.atualizarEmpresa(cnpj,empresa);
                 JOptionPane.showMessageDialog(null, " Foi atualizado com sucesso");
           } 
               
        }
         //PARA IR PARA A TELA DE SENHA           
        if(e.getSource()==TAE.Panel_Senha){     
                    this.TASE.setVisible(true);
                    this.TAE.dispose();
                    ControllerAtualizarSenhaEmpresa CASE = new ControllerAtualizarSenhaEmpresa(TASE);
                    
        }else if(e.getSource()==TAE.Panel_Voltar){
                    //Se clicar em voltar: Torna a tela de menu visível e fecha a tela de atualizar empresa
                    
                    TME.setVisible(true);
                    TAE.dispose();
                    ControllerTelaMenu CTM = new ControllerTelaMenu(TME);
                }

            
        }
      

    public Empresa preencheCamposEmpresa(TelaAtualizarEmpresaVIEW TAE) {
        Empresa empresa1 = eDAO.consultarEmpresa(empresa);
        TAE.txtNomeEmpresa.setText(empresa1.getNome());
        TAE.txtNomeFantasia.setText(empresa1.getNomefantasia());
        TAE.txtEndereco.setText(empresa1.getEndereco());
        TAE.txtBairro.setText(empresa1.getBairro());
        TAE.txtComplemento.setText(empresa1.getComplemento());
        TAE.txtNumeroRua.setText(empresa1.getNumero());
        TAE.ftCep.setText(empresa1.getCep());
        TAE.txtCidade.setText(empresa1.getCidade());
        TAE.txtEstado.setText(empresa1.getEstado());
        TAE.ftCelular.setText(empresa1.getCelular());
        TAE.ftTelefoneFixo.setText(empresa1.getTelefone());
        TAE.txtEmail.setText(empresa1.getEmail());
        TAE.txtRamoEmpresa.setText(empresa1.getRamoempresa());
        TAE.ftCNPJ.setText(empresa1.getCnpj());
       
        
        return empresa1;

    }


    
    
    
    
    
    
    
    
    
    
    
}
