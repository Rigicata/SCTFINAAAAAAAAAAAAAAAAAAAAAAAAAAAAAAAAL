/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Contrato;
import modelDAO.ContratoDAO;
import views.ViewsContrato.TelaAtualizarContratoVIEW;
import views.ViewsContrato.TelaExcluirContratoVIEW;

/**
 *
 * @author wesle
 */
public class ControllerExcluirContrato extends MouseAdapter{
    //Instância de tela
     TelaExcluirContratoVIEW TEC = new TelaExcluirContratoVIEW();
     ContratoDAO cDAO = new ContratoDAO();
     Contrato c = new Contrato();
     TelaAtualizarContratoVIEW TAC = new TelaAtualizarContratoVIEW();
     
     //Construtor para as telas
    public ControllerExcluirContrato(TelaExcluirContratoVIEW TELAEXCLUIRCONTRATO) {
        TEC = TELAEXCLUIRCONTRATO;
        this.TEC.Panel_Excluir.addMouseListener(this);
        this.TEC.Panel_Voltar.addMouseListener(this);
        this.TEC.label_lupa.addMouseListener(this);
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        String id = TEC.txtIdContrato.getText();
        c.setId(id);
        //Buscando por ID
        System.out.println(preencheTabelaContrato(TEC.tbContrato));
        if(e.getSource()==TEC.label_lupa){
            
            if(preencheTabelaContrato(TEC.tbContrato)==true){
                preencheTabelaContrato(TEC.tbContrato);
                
            }else {
                JOptionPane.showMessageDialog(null,"Esse id não existe");
            }

        }
        
        
        
          //Se ele clicar em voltar
      if(e.getSource()==TEC.Panel_Voltar){
          this.TAC.setVisible(true);
          this.TEC.dispose();
          ControllerAtualizarContrato CAC = new ControllerAtualizarContrato(TAC);
          
      }
      
      
      
      
       //Excluindo um contrato
      if(e.getSource()==TEC.Panel_Excluir){
         int confirmarexclusao = JOptionPane.showConfirmDialog(null, "Tem certeza que quer excluir esse contrato?");
            
            if(confirmarexclusao==JOptionPane.YES_OPTION){
                cDAO.excluirContrato(c);
                JOptionPane.showMessageDialog(null,"Exclusão feita com sucesso");
                TAC.setVisible(true);
                TEC.dispose();
                ControllerAtualizarContrato CAC = new ControllerAtualizarContrato(TAC);
                
                
            }else{
                JOptionPane.showMessageDialog(null, "Houve algum erro na exclusão");
            }
        
          
          
      }



    }
    
    public boolean preencheTabelaContrato(JTable tabela) {
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);
        
        tabelado.addColumn("NOME");
        tabelado.addColumn("CPF_FUNCIONARIO");
        tabelado.addColumn("CNPJ_EMPRESA");
        tabelado.addColumn("ID_CONTRATO");
        tabelado.addColumn("DIA_INICIAL");
        tabelado.addColumn("DIA_FINAL");
        tabelado.addColumn("HORARIO INICIAL");
        tabelado.addColumn("HORARIO FINAL");
        tabelado.addColumn("LOCALIZACAO");
        tabelado.addColumn("TIPO");
        tabelado.addColumn("CLAUSULA");
        tabelado.addColumn("STATUS"); 
               
        Object[] coluna = new Object[12];
        ArrayList<Contrato> contratos = cDAO.listarContratosEmpresa(c);
        int cont =0;
        for (int i = 0; i < contratos.size(); i++) {
            cont=1;
            coluna[0] = contratos.get(i).getNomefuncionario();
            coluna[1] = contratos.get(i).getCpf_Funcionario();
            coluna[2] = contratos.get(i).getCnpj_Empresa();
            coluna[3] = contratos.get(i).getId();
            coluna[4] = contratos.get(i).getDiaincial();
            coluna[5] = contratos.get(i).getDiafinal();
            coluna[6] = contratos.get(i).getHorarioinicial();
            coluna[7] = contratos.get(i).getHorariofinal();
            coluna[8] = contratos.get(i).getLocalizacao();
            coluna[9] = contratos.get(i).getTipo();
            coluna[10] = contratos.get(i).getClausula();
            coluna[11] = contratos.get(i).getStatus();
            
            tabelado.addRow(coluna);
            
            
        }
        tabela.setModel(tabelado);
        if(cont ==1){
            return true;
            
        }else{
           return false; 
        }
        
    }
    
}
