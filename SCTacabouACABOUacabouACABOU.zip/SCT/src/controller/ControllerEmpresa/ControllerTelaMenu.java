/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import views.ViewsContrato.TelaContratoVIEW;
import views.ViewsEmpresa.TelaAtualizarEmpresaVIEW;
import views.ViewsEmpresa.TelaAtualizarFuncionarioVIEW;
import views.ViewsEmpresa.TelaConsultarFuncionarioVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerTelaMenu extends MouseAdapter {
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    TelaAtualizarEmpresaVIEW TAE = new TelaAtualizarEmpresaVIEW();
    TelaContratoVIEW TC = new TelaContratoVIEW();
    TelaConsultarFuncionarioVIEW TCF = new TelaConsultarFuncionarioVIEW();
 
    public ControllerTelaMenu(TelaMenuEmpresaVIEW TELAMENUEMPRESA) {
      this.TME =  TELAMENUEMPRESA;
      this.TME.Painel_Contrato.addMouseListener(this);
      this.TME.Painel_Empresa.addMouseListener(this);
      this.TME.Painel_Funcionario.addMouseListener(this);
    
    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
        if(e.getSource()==this.TME.Painel_Empresa){
            this.TAE.setVisible(true);
            this.TME.dispose();
            ControllerTelaAtualizarEmpresa CTAE = new ControllerTelaAtualizarEmpresa(TAE);
        }else if(e.getSource()==this.TME.Painel_Funcionario){
            this.TCF.setVisible(true);
            this.TME.dispose();
            ControllerConsultarFuncionario CTCF = new ControllerConsultarFuncionario(TCF);
        }else if(e.getSource()==this.TME.Painel_Contrato){
            this.TC.setVisible(true);
            this.TME.dispose();
            ControllerCadastrarContrato CCC= new ControllerCadastrarContrato(TC);
            
        }
    }
    
    
    
    
    
}
