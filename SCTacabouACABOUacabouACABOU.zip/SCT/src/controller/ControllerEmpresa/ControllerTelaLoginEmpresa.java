/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import ControllerMaster.ControllerMaster;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Empresa;
import modelDAO.EmpresaDAO;
import views.Principal.TelaInicialVIEW;
import views.ViewsEmpresa.TelaLoginEmpresaVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import views.ViewsFuncionario.TelaLoginFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerTelaLoginEmpresa extends MouseAdapter{

    
   TelaLoginEmpresaVIEW TLE = new TelaLoginEmpresaVIEW();
    TelaInicialVIEW TI= new TelaInicialVIEW();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    EmpresaDAO eDAO = new EmpresaDAO();

    
    
    
    //Construtor
    public ControllerTelaLoginEmpresa(TelaLoginEmpresaVIEW TelaloginEmpresa) {
    this.TLE = TelaloginEmpresa;
    this.TLE.Painel_Entrar.addMouseListener(this);
    this.TLE.Painel_Voltar.addMouseListener(this);
    
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
       
        
        if(me.getSource()==TLE.Painel_Entrar){
            Empresa empresa = new Empresa();
            String senha = new String (TLE.txtSenha.getPassword());
            String cnpj =  TLE.ftCNPJ.getText();
            empresa.setCnpj(cnpj);
            empresa.setSenha(senha);
            
            if(eDAO.verificaLogin(empresa)){
                this.TME.setVisible(true);
                this.TLE.dispose();
                ControllerTelaMenu CCCF= new ControllerTelaMenu(TME);
                
                
                
            }else {
                JOptionPane.showMessageDialog(null, "Senha ou usuário incorretos");
            }
            
            
        }else if(me.getSource()==TLE.Painel_Voltar){
            TI.dispose();
          
            TI.setVisible(true);
            
            
            this.TLE.dispose();
 
            ControllerMaster CM = new ControllerMaster(TI);
           
            
            
        }
        
        
        


}
}
