/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.Contrato;
import modelDAO.ContratoDAO;
import views.ViewsContrato.TelaAtualizarContratoVIEW;
import views.ViewsContrato.TelaContratoVIEW;
import views.ViewsEmpresa.TelaAtualizarEmpresaVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerCadastrarContrato extends MouseAdapter {

    TelaContratoVIEW TC = new TelaContratoVIEW();
    ContratoDAO cDAO = new ContratoDAO();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    TelaAtualizarContratoVIEW TAC = new TelaAtualizarContratoVIEW();
    Contrato contrato = new Contrato();
    public ControllerCadastrarContrato(TelaContratoVIEW TELACONTRATO) {
        TC = TELACONTRATO;
        this.TC.Panel_Atualizar.addMouseListener(this);
        this.TC.Panel_Cadastrar.addMouseListener(this);
        this.TC.Panel_Voltar.addMouseListener(this);

    }

    

    @Override
    public void mouseClicked(MouseEvent e) {
        
        
        //TRÊS BOTOES: CADASTRAR, VOLTAR, ATUALIZAR
        
        //CADASTRANDO UM USUÁRIO
        if (e.getSource() == this.TC.Panel_Cadastrar) {
            
            contrato.setId((TC.txtIdContrato.getText()));
            contrato.setCnpj_Empresa(TC.ftCNPJ.getText());
            contrato.setCpf_Funcionario(TC.ftCPF.getText());
            contrato.setDiaincial(((JTextField) TC.djDiaInicial.getDateEditor().getUiComponent()).getText());
            contrato.setDiafinal(((JTextField) TC.djDiaFinal.getDateEditor().getUiComponent()).getText());
            contrato.setHorarioinicial(TC.ftHoraInicial.getText());
            contrato.setHorariofinal(TC.ftHoraFinal.getText());
            contrato.setLocalizacao(TC.txtLocal.getText());
            contrato.setTipo(TC.cb_tipo.getSelectedItem().toString());
            contrato.setStatus(TC.cbStatus.getSelectedItem().toString());
            contrato.setClausula(TC.txtClausula.getText());
            
            cDAO.cadastrarContrato(contrato);
            JOptionPane.showMessageDialog(null, "Contrato cadastrado com sucesso");
           }

            //ATUALIZANDO UM FUNCIONARIO: FECHA ESSA TELA E CHAMA A DE ATUALIZAR CONTRATO
         if (e.getSource() == this.TC.Panel_Atualizar) {
              this.TAC.setVisible(true);
            this.TC.dispose();
            ControllerAtualizarContrato CAC = new ControllerAtualizarContrato(TAC);
         }
           

            //VOLTAR: VOLTA PARA O MENU PRINCIPAL
         if (e.getSource() == this.TC.Panel_Voltar) {
            TME.setVisible(true);
            this.TC.dispose();
            ControllerTelaMenu CTM = new ControllerTelaMenu(TME);

        }

   

}
    
}
