/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Funcionario;
import modelDAO.FuncionarioDAO;
import views.ViewsEmpresa.TelaAtualizarFuncionarioVIEW;
import views.ViewsEmpresa.TelaCadastrarFuncionarioVIEW;
import views.ViewsEmpresa.TelaConsultarFuncionarioVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerConsultarFuncionario extends MouseAdapter {

    TelaConsultarFuncionarioVIEW TCONF = new TelaConsultarFuncionarioVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    TelaAtualizarFuncionarioVIEW TAF = new TelaAtualizarFuncionarioVIEW();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    TelaCadastrarFuncionarioVIEW TCAD = new TelaCadastrarFuncionarioVIEW();
    Funcionario funcionario1 = new Funcionario();
    

    public ControllerConsultarFuncionario(TelaConsultarFuncionarioVIEW TELACONSULTARCONTRATO) {
        TCONF = TELACONSULTARCONTRATO;
        this.TCONF.Painel_Atualizar.addMouseListener(this);
        this.TCONF.Painel_Cadastrar.addMouseListener(this);
        this.TCONF.pesquisar.addMouseListener(this);
        this.TCONF.Painel_Menu.addMouseListener(this);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
        //PASSANDO O CPF PARA DENTRO DE UM FUNCIONÁRIO PARA PUXAR SEUS DADOS
        String cpf = TCONF.ftCPF.getText();
        funcionario1.setCpf(cpf);
        
        
        //PESQUISAR UM FUNCIONARIO PELO CPF
        if (e.getSource() == TCONF.pesquisar) {
            if(funcionario1.getCpf() != null){
                
            preencheTabelaporCPF(TCONF.tb_Funcionario);
        } else {
            JOptionPane.showMessageDialog(null, "ESTE CPF NÃO EXISTE");
        }
     } 
        // FAZENDO AS FUNÇÕES DOS TRÊS BOTÕES DA TELA DE CONSULTAR FUNCIONÁRIO
        //BOTÃO ATUALIZAR: FECHA A TELA DE CONSULTA E CHAMA O CONTROLLER DE ATUALIZARFUNCIONARIO
        if (e.getSource() == TCONF.Painel_Atualizar) {
            
            this.TAF.setVisible(true);
            this.TCONF.dispose();
            ControllerAtualizarFuncionario CAF = new ControllerAtualizarFuncionario(TAF);
        }
            //BOTÃO CADASTRAR: FECHA A TELA DE CONSULTA E CHAMA O CONTROLLER DE CADASTRAR FUNCIONARIO
       if (e.getSource() == TCONF.Painel_Cadastrar) {
          
            TCAD.setVisible(true);
            TCONF.dispose();
            ControllerCadastrarFuncionario CCADF = new ControllerCadastrarFuncionario(TCAD);
            
        } 
       //BOTÃO MENU: FECHA A TELA DE CONSULTA E CHAMA O CONTROLLER DE ATUALIZARFUNCIONARIO
       if (e.getSource() == TCONF.Painel_Menu) {
            TME.setVisible(true);
            TCONF.dispose();
            ControllerTelaMenu CTM = new ControllerTelaMenu(TME);

        }

    }

   
    public void preencheTabelaporCPF(JTable tabela) {
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);

        tabelado.addColumn("Nome");
        tabelado.addColumn("CPF");
        tabelado.addColumn("RG");
        tabelado.addColumn("Nascimento");
        tabelado.addColumn("Sexo");
        tabelado.addColumn("Endereco");
        tabelado.addColumn("Bairro");
        tabelado.addColumn("Complemento");
        tabelado.addColumn("Número");
        tabelado.addColumn("CEP");
        tabelado.addColumn("Cidade");
        tabelado.addColumn("Estado");
        tabelado.addColumn("Celular");
        tabelado.addColumn("Telefone");
        tabelado.addColumn("Email");

        Object[] coluna = new Object[15];
        Funcionario funcionario = fDAO.consultarFuncionarioCpf(funcionario1);
      
        coluna[0] = funcionario.getNome();
        coluna[1] = funcionario.getCpf();
        coluna[2] = funcionario.getRg();
        coluna[3] = funcionario.getNascimento();
        coluna[4] = funcionario.getSexo();
        coluna[5] = funcionario.getEndereco();
        coluna[6] = funcionario.getBairro();
        coluna[7] = funcionario.getComplemento();
        coluna[8] = funcionario.getNumero();
        coluna[9] = funcionario.getCep();
        coluna[10] = funcionario.getCidade();
        coluna[11] = funcionario.getEstado();
        coluna[12] = funcionario.getCelular();
        coluna[13] = funcionario.getTelefone();
        coluna[14] = funcionario.getEmail();

        tabelado.addRow(coluna);
        

    }
    
    
    
}
