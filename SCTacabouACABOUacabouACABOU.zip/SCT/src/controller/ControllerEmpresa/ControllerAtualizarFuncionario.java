/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Contrato;
import model.Funcionario;
import modelDAO.ContratoDAO;
import modelDAO.FuncionarioDAO;
import views.ViewsContrato.TelaAtualizarContratoVIEW;
import views.ViewsEmpresa.TelaAtualizarFuncionarioVIEW;
import views.ViewsEmpresa.TelaConsultarFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerAtualizarFuncionario extends MouseAdapter {

    TelaAtualizarFuncionarioVIEW TAF = new TelaAtualizarFuncionarioVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    TelaConsultarFuncionarioVIEW TCF = new TelaConsultarFuncionarioVIEW();
    Funcionario f1 = new Funcionario();
    Funcionario funcionario = AtualizarFuncionario(TAF);
    ContratoDAO cDAO = new ContratoDAO();

    public ControllerAtualizarFuncionario(TelaAtualizarFuncionarioVIEW TELAATUALIZARFUNCIONARIO) {
        TAF = TELAATUALIZARFUNCIONARIO;
        this.TAF.Panel_Atualizar.addMouseListener(this);
        this.TAF.Panel_Excluir.addMouseListener(this);
        this.TAF.Panel_Voltar.addMouseListener(this);
        this.TAF.pesquisar.addMouseListener(this);

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        String cpf = TAF.ftCPF.getText();
        f1.setCpf(cpf);
        
        if (e.getSource() == TAF.pesquisar) {
           if(cpf != null){
               preencheCamposFuncionario(TAF);
        }else {
         
            JOptionPane.showMessageDialog(null, "ESSE CPF NÃO CONSTA");
         }
        }
        
        if (e.getSource() == TAF.Panel_Atualizar) {
          
             if(TAF.txtBairro.getText().isEmpty() || TAF.ftCelular.getText().isEmpty() || TAF.ftCep.getText().isEmpty() || TAF.ftCep.getText().isEmpty() || TAF.txtCidade.getText().isEmpty() || TAF.txtComplemento.getText().isEmpty() || TAF.ftCPF.getText().isEmpty() || TAF.txtEmail.getText().isEmpty() || TAF.txtEndereco.getText().isEmpty() || TAF.txtEstado.getText().isEmpty() ||  TAF.ftNascimento.getText().isEmpty() || TAF.txtNomeFuncionario.getText().isEmpty() || TAF.ftCelular.getText().isEmpty() || TAF.ftRg.getText().isEmpty() ||  TAF.ftTelefoneFixo.getText().isEmpty()  ){
               JOptionPane.showMessageDialog(null,"Campo em branco");
        }else { 
            
            funcionario.setBairro(TAF.txtBairro.getText());
            funcionario.setCelular(TAF.ftCelular.getText());
            funcionario.setCep(TAF.ftCep.getText());
            funcionario.setCidade(TAF.txtCidade.getText());
            funcionario.setComplemento(TAF.txtComplemento.getText());
            funcionario.setCpf(TAF.ftCPF.getText());
            funcionario.setEmail(TAF.txtEmail.getText());
            funcionario.setEndereco(TAF.txtEndereco.getText());
            funcionario.setEstado(TAF.txtEstado.getText());
            funcionario.setNascimento(TAF.ftNascimento.getText());
            funcionario.setNome(TAF.txtNomeFuncionario.getText());
            funcionario.setNumero(TAF.txtNumeroRua.getText());
            funcionario.setRg(TAF.ftRg.getText());
            funcionario.setSexo(TAF.combo_sexo.getSelectedItem().toString());
            funcionario.setTelefone(TAF.ftTelefoneFixo.getText());
            
            fDAO.atualizarFuncionario(funcionario);
            JOptionPane.showMessageDialog(null, "Atualizado com Sucesso");
           // limparTela();

        
            //JOptionPane.showMessageDialog(null, "Não foi atualizado com sucesso");

        }
     }  if (e.getSource() == TAF.Panel_Excluir) {
            
          if(cpf != null){
              int confirmarexclusao = JOptionPane.showConfirmDialog(null,"Deseja realmente excluir o funcionario ?");
              if(confirmarexclusao==JOptionPane.YES_OPTION){  
                Funcionario f = AtualizarFuncionario(TAF);
                fDAO.excluirFuncionario(f);
                JOptionPane.showMessageDialog(null, "Excluído com Sucesso");

               int escolha= JOptionPane.showConfirmDialog(null, "Você deseja excluir os contratos antigos desse funcionario");
            if(escolha==JOptionPane.YES_OPTION){
               Contrato c = new Contrato();
               String s = JOptionPane.showInputDialog(null, "Digite o cpf do funcionario");
               c.setCpf_Funcionario(s);
               cDAO.excluirContratoproCPF(c);
               JOptionPane.showMessageDialog(null, "Excluído todos os contratos foram excluídos com sucesso");
          
             }
              
           }else {
               JOptionPane.showMessageDialog(null, "Erro ao excluir funcionario");   
            }  
               
         }      
            
      }     
           
         
            
           
         
            

          

        if (e.getSource() == TAF.Panel_Voltar) {
            TCF.setVisible(true);
            TAF.dispose();
            ControllerConsultarFuncionario CCF = new ControllerConsultarFuncionario(TCF);

        }  
    }


    
 
    public void preencheCamposFuncionario(TelaAtualizarFuncionarioVIEW TAF) {
        Funcionario funcionario = fDAO.consultarFuncionarioCpf(f1);
        TAF.ftCPF.setText(funcionario.getCpf());
        TAF.ftCelular.setText(funcionario.getCelular());
        TAF.ftCep.setText(funcionario.getCep());
        TAF.ftNascimento.setText(funcionario.getNascimento());
        TAF.ftRg.setText(funcionario.getRg());
        TAF.ftTelefoneFixo.setText(funcionario.getTelefone());
        TAF.txtBairro.setText(funcionario.getBairro());
        TAF.txtCidade.setText(funcionario.getCidade());
        TAF.txtComplemento.setText(funcionario.getComplemento());
        TAF.txtEmail.setText(funcionario.getEmail());
        TAF.txtEndereco.setText(funcionario.getEndereco());
        TAF.txtNomeFuncionario.setText(funcionario.getNome());
        TAF.txtNumeroRua.setText(funcionario.getNumero());
        TAF.txtEstado.setText(funcionario.getEstado());
        TAF.combo_sexo.setSelectedItem(funcionario.getSexo());
        
        

    }

    public Funcionario AtualizarFuncionario(TelaAtualizarFuncionarioVIEW TAF) {
        Funcionario funcionario = new Funcionario();
        funcionario.setCpf(TAF.ftCPF.getText());
        funcionario.setCelular(TAF.ftCelular.getText());
        funcionario.setCep(TAF.ftCep.getText());
        funcionario.setNascimento(TAF.ftNascimento.getText());
        funcionario.setRg(TAF.ftRg.getText());
        funcionario.setTelefone(TAF.ftTelefoneFixo.getText());
        funcionario.setBairro(TAF.txtBairro.getText());
        funcionario.setCidade(TAF.txtCidade.getText());
        funcionario.setComplemento(TAF.txtComplemento.getText());
        funcionario.setEmail(TAF.txtEmail.getText());
        funcionario.setEndereco(TAF.txtEndereco.getText());
        funcionario.setNome(TAF.txtNomeFuncionario.getText());
        funcionario.setNumero(TAF.txtNumeroRua.getText());
        funcionario.setEstado(TAF.txtEstado.getText());
        funcionario.setSexo(TAF.combo_sexo.getSelectedItem().toString());
        
        return funcionario;

    }
    
      public void limparTela(){
            TAF.txtBairro.setText(null);
            TAF.ftCelular.setText(null);
            TAF.ftCep.setText(null);
            TAF.txtCidade.setText(null);
            TAF.txtComplemento.setText(null);
            TAF.ftCPF.setText(null);
            TAF.txtEmail.setText(null);
            TAF.txtEndereco.setText(null);
            TAF.txtEstado.setText(null);
            TAF.ftNascimento.setText(null);
            TAF.txtNomeFuncionario.setText(null);
            TAF.txtNumeroRua.setText(null);
            TAF.ftRg.setText(null);
            TAF.ftTelefoneFixo.setText(null);
     }
    
    
    
    

}
