/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.MouseInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Funcionario;
import modelDAO.FuncionarioDAO;
import views.ViewsEmpresa.TelaCadastrarFuncionarioVIEW;
import views.ViewsEmpresa.TelaConsultarFuncionarioVIEW;

/**
 *
 * @author wesle
 */
public class ControllerCadastrarFuncionario extends MouseAdapter {

    TelaCadastrarFuncionarioVIEW TCADF = new TelaCadastrarFuncionarioVIEW();
    Funcionario funcionario = new Funcionario();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    TelaConsultarFuncionarioVIEW TCF = new TelaConsultarFuncionarioVIEW();

    public ControllerCadastrarFuncionario(TelaCadastrarFuncionarioVIEW TELACADASTRARFUNCIONARIO) {
        TCADF = TELACADASTRARFUNCIONARIO;
        this.TCADF.Panel_Cadastrar.addMouseListener(this);
        this.TCADF.Panel_Voltar.addMouseListener(this);

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // DOIS BOTÕES NESSA TELA: CADASTRAR E VOLTAR

        //CADASTRANDO UM FUNCIONARIO
        if (e.getSource() == TCADF.Panel_Cadastrar) {
           if(TCADF.txtBairro.getText().isEmpty() || TCADF.ftCelular.getText().isEmpty() || TCADF.ftCep.getText().isEmpty() || TCADF.ftCep.getText().isEmpty() || TCADF.txtCidade.getText().isEmpty() || TCADF.txtComplemento.getText().isEmpty() || TCADF.ftCPF.getText().isEmpty() || TCADF.txtEmail.getText().isEmpty() || TCADF.txtEndereco.getText().isEmpty() || TCADF.txtEstado.getText().isEmpty() ||  TCADF.ftNascimento.getText().isEmpty() || TCADF.txtNomeFuncionario.getText().isEmpty() || TCADF.ftCelular.getText().isEmpty() || TCADF.ftRg.getText().isEmpty() || (new String (TCADF.txtSenha.getPassword()).isEmpty()) || TCADF.combo_sexo.getSelectedItem().toString().isEmpty() || TCADF.ftTelefoneFixo.getText().isEmpty()  ){
               JOptionPane.showMessageDialog(null,"Campo em branco");
           }else{
            funcionario.setBairro(TCADF.txtBairro.getText());
            funcionario.setCelular(TCADF.ftCelular.getText());
            funcionario.setCep(TCADF.ftCep.getText());
            funcionario.setCidade(TCADF.txtCidade.getText());
            funcionario.setComplemento(TCADF.txtComplemento.getText());
            funcionario.setCpf(TCADF.ftCPF.getText());
            funcionario.setEmail(TCADF.txtEmail.getText());
            funcionario.setEndereco(TCADF.txtEndereco.getText());
            funcionario.setEstado(TCADF.txtEstado.getText());
            funcionario.setNascimento(TCADF.ftNascimento.getText());
            funcionario.setNome(TCADF.txtNomeFuncionario.getText());
            funcionario.setNumero(TCADF.txtNumeroRua.getText());
            funcionario.setRg(TCADF.ftRg.getText());
            funcionario.setSenha (new String (TCADF.txtSenha.getPassword()));
            funcionario.setSexo(TCADF.combo_sexo.getSelectedItem().toString());
            funcionario.setTelefone(TCADF.ftTelefoneFixo.getText());
            fDAO.cadastrarFuncionario(funcionario);
                JOptionPane.showMessageDialog(null, "Funcionario cadastrado com sucesso");
                limparTela();
                
           }
            
            

            //Caso clique no botão voltar: Fecha a tela de Cadastro e chama a de Consultar funcionário, junto com seu controller.
        } else if (e.getSource() == TCADF.Panel_Voltar) {
            TCF.setVisible(true);
            TCADF.dispose();
            ControllerConsultarFuncionario CCF = new ControllerConsultarFuncionario(TCF);

        }

    }

    
    
     public void limparTela(){
            TCADF.txtBairro.setText(null);
            TCADF.ftCelular.setText(null);
            TCADF.ftCep.setText(null);
            TCADF.txtCidade.setText(null);
            TCADF.txtComplemento.setText(null);
            TCADF.ftCPF.setText(null);
            TCADF.txtEmail.setText(null);
            TCADF.txtEndereco.setText(null);
            TCADF.txtEstado.setText(null);
            TCADF.ftNascimento.setText(null);
            TCADF.txtNomeFuncionario.setText(null);
            TCADF.txtNumeroRua.setText(null);
            TCADF.ftRg.setText(null);
            TCADF.txtSenha.setText(null);
            TCADF.combo_sexo.setSelectedItem(null);
            TCADF.ftTelefoneFixo.setText(null);
     }
    
    
    
    
    
}




 