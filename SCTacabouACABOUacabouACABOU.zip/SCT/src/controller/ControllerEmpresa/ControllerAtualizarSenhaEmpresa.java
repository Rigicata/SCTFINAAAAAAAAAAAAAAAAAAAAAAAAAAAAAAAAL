/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Empresa;
import modelDAO.EmpresaDAO;
import views.ViewsEmpresa.TelaAtualizarSenhaEmpresaVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;

/**
 *
 * @author wesle
 */
public class ControllerAtualizarSenhaEmpresa extends MouseAdapter{
   TelaAtualizarSenhaEmpresaVIEW TASE = new TelaAtualizarSenhaEmpresaVIEW();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    EmpresaDAO eDAO = new EmpresaDAO();
    
    
    public ControllerAtualizarSenhaEmpresa(TelaAtualizarSenhaEmpresaVIEW TELAATUALIZARSENHAEMPRESA) {
      this.TASE = TELAATUALIZARSENHAEMPRESA;
      this.TASE.Panel_Atualizar.addMouseListener(this);
      this.TASE.Panel_Menu.addMouseListener(this);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
            Empresa empresa = new Empresa();
            
            String senhaAntiga = new String (TASE.txtSenhaAntiga.getPassword());
            String senhaNova = new String (TASE.txtSenhaNova.getPassword());
            String cnpj  = TASE.ftCNPJ.getText();
            
            empresa.setSenha(senhaNova);
        
        
        
       if(e.getSource()==TASE.Panel_Atualizar){
           if(senhaAntiga.equals(senhaNova)){
                
                
                JOptionPane.showMessageDialog(null, "Mesma Senha");
           }else if(senhaAntiga.isEmpty() || senhaNova.isEmpty()) {
               JOptionPane.showMessageDialog(null,"Campo vazio");
           }else{
               eDAO.mudarSenhaEmpresa(senhaNova,cnpj);
               JOptionPane.showMessageDialog(null, "Senha Atualizada com sucesso !!! ");
           }
           
       }else if(e.getSource()==this.TASE.Panel_Menu){
           this.TME.setVisible(true);
           this.TASE.dispose();
           ControllerTelaMenu CTM = new ControllerTelaMenu(TME);
           
       }

    }
    
    
}
