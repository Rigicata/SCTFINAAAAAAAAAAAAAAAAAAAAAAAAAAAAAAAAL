/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerFuncionario;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Funcionario;
import modelDAO.FuncionarioDAO;
import views.ViewsFuncionario.TelaAtualizarSenhaFuncionarioVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;

/**
 *
 * @author aluno
 */
public class ControllerAtualizarSenhaFuncionario extends MouseAdapter{
    TelaAtualizarSenhaFuncionarioVIEW TASF = new TelaAtualizarSenhaFuncionarioVIEW();
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    
    public ControllerAtualizarSenhaFuncionario(TelaAtualizarSenhaFuncionarioVIEW telaatualizarsenhafuncionario,String cpf) {
      this.TASF = telaatualizarsenhafuncionario;
      this.TASF.Panel_Atualizar.addMouseListener(this);
      this.TASF.Panel_Contrato.addMouseListener(this);
      TASF.ftCPF.setText(cpf);
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
       Funcionario funcionario = new Funcionario();
            String senhaAntiga = new String (TASF.txtSenhaAntiga.getPassword());
            String senhaNova = new String (TASF.txtSenhaNova.getPassword());
          //  String cpf  = TASF.ftCPF.getText();
            funcionario.setSenha(senhaNova);
                    
        
        if(me.getSource()==TASF.Panel_Atualizar){
           if(senhaAntiga.equals(senhaNova)){
               
               JOptionPane.showMessageDialog(null,"Mesma senha");
           }else if(senhaAntiga.isEmpty() || senhaNova.isEmpty()){
               JOptionPane.showMessageDialog(null,"Campo vazio");
           }else {
               fDAO.mudarSenhaFuncionario(TASF.ftCPF.getText(),senhaNova);
               JOptionPane.showMessageDialog(null, "Senha atualizada com suceso");
           }
           
       }else if(me.getSource()==TASF.Panel_Contrato){
           this.TCCF.setVisible(true);
           this.TASF.dispose();
           ControllerConsultarContratoFuncionario CTI = new ControllerConsultarContratoFuncionario(TCCF,TASF.ftCPF.getText());
           
       }
        //fDAO.mudarSenhaFuncionario(senhaNova);
      //TASF.txtSenhaAntiga!=TASF.txtSenhaNova
       /*
       if(e.getSource()==TASE.Panel_Atualizar){
           if(TASE.txtSenhaAntiga!=TASE.txtSenhaNova){
                eDAO.mudarSenhaEmpresa(new String(this.TASE.txtSenhaNova.getPassword()));
                JOptionPane.showMessageDialog(null, "Senha Alterada com sucesso");
           }else {
               JOptionPane.showMessageDialog(null,"Senhas permanecem iguais. Mude a senha nova.");
           }
       */




    }

   
    
    
    
    
    
    
}
