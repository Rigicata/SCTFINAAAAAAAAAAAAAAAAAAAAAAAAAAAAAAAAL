/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerFuncionario;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Contrato;
import model.Funcionario;
import modelDAO.ContratoDAO;
import views.ViewsFuncionario.TelaAtualizarSenhaFuncionarioVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;

/**
 *
 * @author aluno
 */
public class ControllerConsultarContratoFuncionario extends MouseAdapter{
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    TelaAtualizarSenhaFuncionarioVIEW TASF = new TelaAtualizarSenhaFuncionarioVIEW();
    ContratoDAO cDAO = new ContratoDAO();
    Contrato contrato = new Contrato();
    
         
   

    public ControllerConsultarContratoFuncionario(TelaConsultarContratoFuncionarioVIEW telaconsultarcontratoFuncionario,String cpf) {
      this.TCCF = telaconsultarcontratoFuncionario;
      this.TCCF.label_PesquisarCPF.addMouseListener(this);
      this.TCCF.Painel_Atualizar.addMouseListener(this);
      TCCF.ftCPF.setText(cpf);
     
      //this.preencheTabelaporEMANDAMENTO(this.TCCF.tb_FuncionarioEmAdamento);
      //this.preencheTabelaporCPFFEITO(this.TCCF.tb_FuncionarioFeito);
     
      //Ver como fazer com o campo do ID contrato


    }
    
   
    @Override
    public void mouseClicked(MouseEvent me) {
         String cpf2 = TCCF.ftCPF.getText();
         contrato.setCpf_Funcionario(cpf2);
         
     if(me.getSource()==TCCF.label_PesquisarCPF){
                
                preencheTabelaporEMANDAMENTO(TCCF.tb_FuncionarioEmAdamento);
                preencheTabelaporCPFFEITO(TCCF.tb_FuncionarioFeito);
                
       }
       
        
        
        
        
        if(me.getSource()==TCCF.Painel_Atualizar){
            
            this.TASF.setVisible(true);
            this.TCCF.dispose();
            ControllerAtualizarSenhaFuncionario CASF = new ControllerAtualizarSenhaFuncionario(TASF,cpf2);
            
        }











    }
    

    
    public void preencheTabelaporEMANDAMENTO(JTable tabela){ 
    DefaultTableModel tabelado = new DefaultTableModel();
    tabela.setModel(tabelado);
        tabelado.addColumn("Nome");
        tabelado.addColumn("CPF");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Cláusulas");
        tabelado.addColumn("Status");
        
        Object[] coluna = new Object[12];
       
        ArrayList<Contrato> contratos = cDAO.pesquisarContratoporCPFemAndamento(contrato);
       
        for(int i=0;i<contratos.size();i++){
            coluna[0] = contratos.get(i).getNomefuncionario();
            coluna[1] = contratos.get(i).getCpf_Funcionario();
            coluna[2] = contratos.get(i).getCnpj_Empresa();
            coluna[3] = contratos.get(i).getId();
            coluna[4] = contratos.get(i).getDiaincial();
            coluna[5] = contratos.get(i).getDiafinal();
            coluna[6] = contratos.get(i).getHorarioinicial();
            coluna[7] = contratos.get(i).getHorariofinal();
            coluna[8] = contratos.get(i).getLocalizacao();
            coluna[9] = contratos.get(i).getTipo();
            coluna[10] = contratos.get(i).getClausula();
            coluna[11] = contratos.get(i).getStatus();
           
            
           tabelado.addRow(coluna);
          
              
              
          }
        tabela.setModel(tabelado);
         
    }

        
    public void preencheTabelaporCPFFEITO(JTable tabela){
         DefaultTableModel tabelado = new DefaultTableModel();
         tabela.setModel(tabelado);
        tabelado.addColumn("NOME");
        tabelado.addColumn("CPF");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Clausulas");
        tabelado.addColumn("Status");
        Object[] coluna = new Object[12];
        
        
        
          ArrayList<Contrato>contratos = cDAO.pesquisarContratoporCPFfeito(contrato);
          
           
            for(int i=0;i<contratos.size();i++){
            coluna[0] = contratos.get(i).getNomefuncionario();
            coluna[1] = contratos.get(i).getCpf_Funcionario();
            coluna[2] = contratos.get(i).getCnpj_Empresa();
            coluna[3] = contratos.get(i).getId();
            coluna[4] = contratos.get(i).getDiaincial();
            coluna[5] = contratos.get(i).getDiafinal();
            coluna[6] = contratos.get(i).getHorarioinicial();
            coluna[7] = contratos.get(i).getHorariofinal();
            coluna[8] = contratos.get(i).getLocalizacao();
            coluna[9] = contratos.get(i).getTipo();
            coluna[10] = contratos.get(i).getClausula();
            coluna[11] = contratos.get(i).getStatus();
           
           
            
           tabelado.addRow(coluna);
           
              
              
          } 
           
          tabela.setModel(tabelado);  
        
    }
    
    
    
}
