/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerFuncionario;

import ControllerMaster.ControllerMaster;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import model.Funcionario;
import modelDAO.FuncionarioDAO;
import views.Principal.TelaInicialVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;
import views.ViewsFuncionario.TelaLoginFuncionarioVIEW;

/**
 *
 * @author aluno
 */
public class ControllerLoginFuncionario extends MouseAdapter{
    
    TelaLoginFuncionarioVIEW TLF = new TelaLoginFuncionarioVIEW();
    TelaInicialVIEW TI= new TelaInicialVIEW();
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();

    
    
    
    //Construtor
    public ControllerLoginFuncionario(TelaLoginFuncionarioVIEW TelaloginFuncionario) {
    this.TLF = TelaloginFuncionario;
    this.TLF.Painel_Entrar.addMouseListener(this);
    this.TLF.Painel_Voltar.addMouseListener(this);
    
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
            Funcionario funcionario = new Funcionario();
            String senha = new String (TLF.txtSenha.getPassword());
            String cpf =  TLF.ftCPF.getText();
            funcionario.setCpf(cpf);
            funcionario.setSenha(senha);
        
        if(me.getSource()==TLF.Painel_Entrar){
            if(fDAO.verificaLogin(funcionario)==true){
                this.TCCF.setVisible(true);
                this.TLF.dispose();
                ControllerConsultarContratoFuncionario CCCF= new ControllerConsultarContratoFuncionario(TCCF,cpf);
                
                
                
            }else {
                JOptionPane.showMessageDialog(null, "Senha ou usuário incorretos");
            }
            
            
        }else if(me.getSource()==TLF.Painel_Voltar){
            
            TI.setVisible(true);
            
            
            this.TLF.dispose();
 
            ControllerMaster CM = new ControllerMaster(TI);
           
            
            
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
}
