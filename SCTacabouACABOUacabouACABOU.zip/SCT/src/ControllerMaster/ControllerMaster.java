package ControllerMaster;



import controller.ControllerEmpresa.ControllerTelaLoginEmpresa;
import controller.ControllerFuncionario.ControllerLoginFuncionario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import views.Principal.TelaInicialVIEW;
import views.ViewsEmpresa.TelaLoginEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;
import views.ViewsFuncionario.TelaLoginFuncionarioVIEW;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class ControllerMaster extends MouseAdapter {

    TelaInicialVIEW TI = new TelaInicialVIEW();
     TelaLoginFuncionarioVIEW TLF = new TelaLoginFuncionarioVIEW();
     
    
    public ControllerMaster(TelaInicialVIEW TELAI){
        
        TI = TELAI;

        this.TI.Painel_Empresa.addMouseListener(this);
        this.TI.Painel_Funcionario.addMouseListener(this);
        //this.TI.btnTeste.addActionListener(this);
        //TI.setVisible(true);
    }

   

   
    
  
    
   @Override
   public void mouseClicked (MouseEvent e){
       
       //TelaInicialVIEW TI = new TelaInicialVIEW();
      //TI.setVisible(true);
       if(e.getSource()==TI.Painel_Empresa){
            TelaLoginEmpresaVIEW TLE = new TelaLoginEmpresaVIEW();
            TLE.setVisible(true);
            TI.dispose();
            ControllerTelaLoginEmpresa CTLE = new ControllerTelaLoginEmpresa(TLE);
            
            
            
            //Caso ele clique em Funcionário
        }else if(e.getSource()==TI.Painel_Funcionario){ 
           
           TI.dispose();
            TLF.setVisible(true);
            
            TI.dispose();
            ControllerLoginFuncionario CFC = new ControllerLoginFuncionario(TLF);
       
        
        
        }
        

   }

 
        
   
        
    
    }


  

