/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDAO;

import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.Conexao;
import model.Contrato;
import model.Funcionario;

/**
 *
 * @author aluno
 */
public class ContratoDAO {

    Conexao conexao;
    PreparedStatement pst;

    public ContratoDAO() {
        this.conexao = new Conexao();

    }

    public void cadastrarContrato(Contrato contrato) {
        try {
            Connection conecta = this.conexao.conector();
            String sql = "insert into contrato(idContrato,cnpj_Empresa,cpf_Funcionario,dia_Inicial,dia_Final,horario_Inicial,horario_Final,localizacao,tipo,clausula,funcionario_Status)"
                    + "values(?,?,?,?,?,?,?,?,?,?,?)"; // para o banco

            pst = conecta.prepareCall(sql); //Passando o  para o banco

            //Cadastro das informações
            pst.setString(1, contrato.getId());
            pst.setString(2, contrato.getCnpj_Empresa());
            pst.setString(3, contrato.getCpf_Funcionario());
            pst.setString(4, contrato.getDiaincial());
            pst.setString(5, contrato.getDiafinal());
            pst.setString(6, contrato.getHorarioinicial());
            pst.setString(7, contrato.getHorariofinal());
            pst.setString(8, contrato.getLocalizacao());
            pst.setString(9, contrato.getTipo());
            pst.setString(10, contrato.getClausula());
            pst.setString(11, contrato.getStatus());
            
            
            pst.executeUpdate(); // Fazendo o Uptade no banco

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no cadatrar Contrato :" + e.getMessage());

        }
    }

    public  ArrayList<Contrato> pesquisarContratoporCPFemAndamento(Contrato contrato) {
        String sql = "select nome_funcionario,cpf_Funcionario,cnpj_Empresa,idContrato,dia_Inicial,dia_Final,\n" +
"horario_Inicial,horario_Final,localizacao,tipo,clausula,Funcionario_Status\n" +
"from funcionario inner join contrato on  cpf=cpf_Funcionario and Funcionario_Status = 'EM ANDAMENTO' where cpf_Funcionario = ?";
        
      
        ArrayList<Contrato> contratos = new ArrayList<>(); ;
        

       
      
       
        try {
             
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
          
            pst.setString(1, contrato.getCpf_Funcionario());
           
            
            
            ResultSet rs = pst.executeQuery();  
                  
            while (rs.next()) {
                
                 contrato = new Contrato();
               
                contrato.setNomefuncionario(rs.getString(("nome_funcionario")));
                contrato.setCpf_Funcionario(rs.getString("cpf_Funcionario"));
                contrato.setCnpj_Empresa(rs.getString("cnpj_Empresa"));
                contrato.setId((rs.getString("idContrato")));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setClausula(rs.getString("clausula"));
                contrato.setStatus(rs.getString("Funcionario_Status"));
                 System.out.println("EM ANDAMENTO : "+contrato.getCpf_Funcionario());
                
                contratos.add(contrato);

            }
          

        } catch (Exception e) {
            System.out.println("Erro pesquisar contrato por CPF em andamento: " + e.getMessage());
        }

        return contratos;
    }
    
     public  ArrayList<Contrato> pesquisarContratoporCPFfeito(Contrato contrato) {
        String sql = "select nome_funcionario,cpf_Funcionario,cnpj_Empresa,idContrato,dia_Inicial,dia_Final,\n" +
"horario_Inicial,horario_Final,localizacao,tipo,clausula,Funcionario_Status\n" +
"from funcionario inner join contrato on  cpf=cpf_Funcionario and Funcionario_Status = 'CONCLUÍDO' where cpf_Funcionario = ?";
        
      
        ArrayList<Contrato> contratos = new ArrayList<>(); ;
        

       
      
       
        try {
             
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
          
            pst.setString(1, contrato.getCpf_Funcionario());
           
            
            
            ResultSet rs = pst.executeQuery();  
                  
            while (rs.next()) {
                
                 contrato = new Contrato();
               
                contrato.setNomefuncionario(rs.getString(("nome_funcionario")));
                contrato.setCpf_Funcionario(rs.getString("cpf_Funcionario"));
                contrato.setCnpj_Empresa(rs.getString("cnpj_Empresa"));
                contrato.setId((rs.getString("idContrato")));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setClausula(rs.getString("clausula"));
                contrato.setStatus(rs.getString("Funcionario_Status"));
                 System.out.println("EM ANDAMENTO : "+contrato.getCpf_Funcionario());
                
                contratos.add(contrato);

            }
          

        } catch (Exception e) {
            System.out.println("Erro pesquisar contrato por CPF em andamento: " + e.getMessage());
        }

        return contratos;
    }
    
    
    public void excluirContrato(Contrato contrato) {

        try {
            Connection conecta = this.conexao.conector();
            String sql = "delete from contrato where idContrato=?";
            pst = conecta.prepareCall(sql);
            

            //Excluindo das informações
            
            pst.setString(1, contrato.getId());
         
           

            pst.executeUpdate(); // Fazendo o Uptade no banco

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro na exclusão do contrato: " + e.getMessage());

        }

    }

    public void atualizarContrato(String id,Contrato contrato,String dataInicial, String dataFinal) {
        String sql = "update contrato set dia_Inicial=?,dia_Final=?,horario_Inicial=?,horario_Final=?,localizacao=?,tipo=?,clausula=?,funcionario_Status=?  where idContrato = ?";
            //PRECISA IDENTIFICAR O ID DO CONTRATO PARA FAZER O UPDATE
            
        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql); //Passando o  para o banco

            
            
            
          // String dinicial  = ((JTextField)dataInicial.getDateEditor().getUiComponent()).getText();
          // String dfinal  = ((JTextField)dataFinal.getDateEditor().getUiComponent()).getText();
           contrato.setDiaincial(dataInicial);
           contrato.setDiafinal(dataFinal);
           
            pst.setString(1, contrato.getDiaincial());
            pst.setString(2, contrato.getDiafinal());
            pst.setString(3, contrato.getHorarioinicial());
            pst.setString(4, contrato.getHorariofinal());
            pst.setString(5, contrato.getLocalizacao());
            pst.setString(6, contrato.getTipo());
            pst.setString(7, contrato.getClausula());
            pst.setString(8, contrato.getStatus());
          
            pst.setString(9, contrato.getId());
            

            pst.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no banco atualizar contrato:" + e.getMessage());

        }

    }

    
   
    public ArrayList<Contrato>listarContratosEmpresa(Contrato contrato) {
        String sql = "select nome_funcionario,cpf_Funcionario,cnpj_Empresa,idContrato,dia_Inicial,dia_Final,\n" +
"horario_Inicial,horario_Final,localizacao,tipo,clausula,Funcionario_Status\n" +
"from funcionario inner join contrato on  cpf=cpf_Funcionario where idContrato = ?";
        
        
        ArrayList<Contrato> contratos = new ArrayList<>();
       

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            pst.setString(1, contrato.getId());
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                
                
                contrato = new Contrato();
                
                
                contrato.setNomefuncionario(rs.getString(("nome_funcionario")));
                contrato.setCpf_Funcionario(rs.getString("cpf_Funcionario"));
                contrato.setCnpj_Empresa(rs.getString("cnpj_Empresa"));
                contrato.setId((rs.getString("idContrato")));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setClausula(rs.getString("clausula"));
                contrato.setStatus(rs.getString("Funcionario_Status"));
                
          
                contratos.add(contrato);

            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        return contratos;
    }
  
  public Contrato pesquisarContratosporIdIndividual(Contrato contrato) {

        String sql = "select*from contrato where idContrato=?";

        

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            pst.setString(1, contrato.getId());
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                
                contrato.setId((rs.getString("idContrato")));
                contrato.setCnpj_Empresa(rs.getString("cnpj_Empresa"));
                contrato.setCpf_Funcionario(rs.getString("cpf_Funcionario"));
                contrato.setDiaincial((rs.getString("dia_Inicial")));
                contrato.setDiafinal((rs.getString("dia_Final")));
                contrato.setHorarioinicial((rs.getString("horario_Inicial")));
                contrato.setHorariofinal((rs.getString("horario_Final")));
                contrato.setLocalizacao((rs.getString ("localizacao")));
                contrato.setTipo((rs.getString("tipo")));
                contrato.setClausula((rs.getString("clausula")));
                contrato.setStatus((rs.getString("funcionario_Status")));
               

            }

        } catch (Exception e) {
            System.out.println("Erro no pesquisar Contrato: " + e.getMessage());
        }

        return contrato;
    }
  
  
  
  
   public Contrato listarData(Contrato contrato){
           String sql = "select dia_Inicial,dia_Final from funcionario inner join contrato  on cpf=cpf_Funcionario where idContrato = ?";
           
           
           try {
           Connection conecta = this.conexao.conector();
             pst = conecta.prepareCall(sql);
             pst.setString(1,contrato.getId());
           
             ResultSet rs = pst.executeQuery();
              while(rs.next()){
                contrato= new Contrato();
                
              contrato.setDiaincial(rs.getString("dia_Inicial"));
              contrato.setDiafinal(rs.getString("dia_Final"));
              }
       } catch (Exception e) {
              System.out.println("Erro no listarData: "+e.getMessage()); 
               
               
       }
 
             
                
               
      return contrato;          
              
               

}
                        
   
   
    public void excluirContratoproCPF(Contrato contrato) {

        try {
            Connection conecta = this.conexao.conector();
            String sql = "delete from contrato where cpf_Funcionario=?";
            pst = conecta.prepareCall(sql);
            

            //Excluindo das informações
            
            pst.setString(1, contrato.getCpf_Funcionario());
         
           

            pst.executeUpdate(); // Fazendo o Uptade no banco

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro na exclusão do contrato: " + e.getMessage());

        }

    }
   
   
   
   

   }



