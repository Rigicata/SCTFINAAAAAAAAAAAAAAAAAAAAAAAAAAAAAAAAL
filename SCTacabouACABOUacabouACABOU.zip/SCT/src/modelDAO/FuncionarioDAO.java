/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Conexao;
import model.Funcionario;


/**
 *
 * @author aluno
 */
public class FuncionarioDAO {
    Conexao conexao;
    PreparedStatement pst;
    ResultSet rs;
    
  public FuncionarioDAO(){
        this.conexao = new Conexao();
        
        
    }
  
  
    
  public void cadastrarFuncionario(Funcionario funcionario){
       try {
           Connection conecta =  this.conexao.conector();
           String sql = "insert into funcionario(nome_funcionario,endereco,bairro,complemento,numero,cep,cidade,estado,celular,telefone,email,nascimento,cpf,rg,sexo,senha)"
                         +"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; //Script para o banco
                                      
            
          pst=conecta.prepareCall(sql); //Passando o script para o banco
          
          //Cadastro das informações
          
            pst.setString(1, funcionario.getNome()); 
            pst.setString(2, funcionario.getEndereco());
            pst.setString(3, funcionario.getBairro());      
            pst.setString(4, funcionario.getComplemento());
            pst.setString(5, funcionario.getNumero());
            pst.setString(6, funcionario.getCep());
            pst.setString(7, funcionario.getCidade());
            pst.setString(8, funcionario.getEstado());
            pst.setString(9, funcionario.getCelular());
            pst.setString(10, funcionario.getTelefone());
            pst.setString(11,  funcionario.getEmail());
            pst.setString(12, funcionario.getNascimento());
            pst.setString(13, funcionario.getCpf());
            pst.setString(14, funcionario.getRg());
            pst.setString(15, funcionario.getSexo());
            pst.setString(16,funcionario.getSenha());
            
            
            pst.executeUpdate(); // Fazendo o Uptade no banco
          
           
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"Erro no CadastrarFuncionario: "+e.getMessage());
       
       
       }
   }      
  
   
   
  public ArrayList<Funcionario> consultarFuncionarioARRAY(){
           String sql = "select*from funcionario where cpf=?";
           ArrayList<Funcionario> funcionarios = new ArrayList<>();
           Funcionario funcionario;
           
           try {
             Connection conecta = this.conexao.conector();
             pst = conecta.prepareCall(sql);
             ResultSet rs = pst.executeQuery();
              while(rs.next()){
                funcionario= new Funcionario();
                funcionario.setBairro(rs.getString("bairro"));
                funcionario.setCelular(rs.getString("celular"));
                funcionario.setCep(rs.getString("cep"));
                funcionario.setCidade(rs.getString("cidade"));
                funcionario.setComplemento(rs.getString("complemento"));
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setEmail(rs.getString("email"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setEstado(rs.getString("estado"));
                funcionario.setNascimento(rs.getString("nascimento"));
                funcionario.setNumero(rs.getString("numero"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
                
                
                /*pst.setString(1, funcionario.getNome()); 
            pst.setString(2, funcionario.getEndereco());
            pst.setString(3, funcionario.getBairro());      
            pst.setString(4, funcionario.getComplemento());
            pst.setString(5, funcionario.getNumero());
            pst.setString(6, funcionario.getCep());
            pst.setString(7, funcionario.getCidade());
            pst.setString(8, funcionario.getEstado());
            pst.setString(9, funcionario.getCelular());
            pst.setString(10, funcionario.getTelefone());
            pst.setString(11,  funcionario.getEmail());
            pst.setString(12, funcionario.getNascimento());
            pst.setString(13, funcionario.getCpf());
            pst.setString(14, funcionario.getSexo());
            pst.setString(15,funcionario.getSenha());*/
                
                funcionarios.add(funcionario);
              }
             
             
             
             
           } catch (Exception e) {
               System.out.println("ErronoConsultarFuncionario: "+e.getMessage()); 
           }
           
           return funcionarios;
       }
  

   
  public void excluirFuncionario(Funcionario funcionario){
      
      
      try {
         Connection conecta = this.conexao.conector();
         String sql = "delete from funcionario where cpf=?";
         pst = conecta.prepareCall(sql);
         
          pst.setString(1, funcionario.getCpf());
          
           
            pst.executeUpdate(); // Fazendo o Uptade no banco
           
       } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "Erro Excluir Funcionario: "+e.getMessage());
       
       }
      
      
       
       
   }
   
   
  public void atualizarFuncionario(Funcionario funcionario){
         String sql ="update funcionario set nome_funcionario=?,endereco=?,bairro=?,complemento=?,numero=?,cep=?,cidade=?,estado=?,celular=?,telefone=?,email=?,nascimento=?,sexo=? where cpf=?"; 
      
       try {
       Connection conecta = this.conexao.conector();
       pst=conecta.prepareCall(sql); //Passando o script para o banco
       
       pst.setString(1, funcionario.getCpf());
       
      //Cadastro das informações
          
            pst.setString(1, funcionario.getNome()); 
            pst.setString(2, funcionario.getEndereco());
            pst.setString(3, funcionario.getBairro());      
            pst.setString(4, funcionario.getComplemento());
            pst.setString(5, funcionario.getNumero());
            pst.setString(6, funcionario.getCep());
            pst.setString(7, funcionario.getCidade());
            pst.setString(8, funcionario.getEstado());
            pst.setString(9, funcionario.getCelular());
            pst.setString(10, funcionario.getTelefone());
            pst.setString(11,  funcionario.getEmail());
            pst.setString(12, funcionario.getNascimento());
            pst.setString(13, funcionario.getSexo());
            pst.setString(14, funcionario.getCpf());
            
           
            
            pst.executeUpdate();
       
       
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Erro atualizar funcionario:"+e.getMessage());
       
       
       }
       
     
       
       
   }
        
   
    
  
  public boolean verificaLogin(Funcionario funcionario){
       
       boolean result = false;
         String sql= "select * from funcionario where cpf = ? and senha = ?";
       try{
           
           
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            pst.setString(1, funcionario.getCpf());
            pst.setString(2, new String (funcionario.getSenha()));            
           // pst.execute();
            //System.out.println(funcionario.getCpf());
            //System.out.println(funcionario.getSenha());
            
              rs = pst.executeQuery();
            while(rs.next()){ 
                String cpf = rs.getString("cpf");
                String senha = rs.getString("senha");
                if(funcionario.getCpf().equals(cpf) && new String (funcionario.getSenha()).equals(senha)){
                    
                    result = true;
                } else{
                   
                    result =  false;
                }
            }
            
        }catch(Exception e){
            System.out.println("Erro login funcionario : "+ e.getMessage());
        }
        return result;
   
  }
    
  
  
  
          
public Funcionario consultarFuncionarioCpf(Funcionario funcionario){
           String sql = "select*from funcionario where cpf=?";
          
           
           try {
             Connection conecta = this.conexao.conector();
             pst = conecta.prepareCall(sql);
             pst.setString(1, funcionario.getCpf());
             
             ResultSet rs = pst.executeQuery();
               System.out.println("rrr" + rs);
             while(rs.next()){
                funcionario.setNome(rs.getString("nome_funcionario"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setBairro(rs.getString("bairro"));
                funcionario.setComplemento(rs.getString("complemento"));
                funcionario.setNumero(rs.getString("numero"));
                funcionario.setCep(rs.getString("cep"));
                funcionario.setCidade(rs.getString("cidade"));
                funcionario.setEstado(rs.getString("estado"));
                funcionario.setCelular(rs.getString("celular"));
                funcionario.setTelefone(rs.getString("telefone"));
                funcionario.setEmail(rs.getString("email"));
                funcionario.setNascimento(rs.getString("nascimento"));
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setRg(rs.getString("rg"));
                funcionario.setSexo(rs.getString("sexo"));
               
             }
             
             
             
           } catch (Exception e) {
               System.out.println("Erro consultar funcionario CPF : "+e.getMessage()); 
           }
           
           return funcionario;
       }
  

  public void mudarSenhaFuncionario(String cpf, String senha){
         String sql ="update  funcionario set senha=? where cpf=?";
        
         Funcionario funcionario = new Funcionario();
         funcionario.setCpf(cpf);
         senha = new String (senha);
         funcionario.setSenha(senha);
       try {
       Connection conecta = this.conexao.conector();
       pst=conecta.prepareCall(sql); //Passando o script para o banco

      //Cadastro das informações
          
         //update administrador set login=?, senha=? where idAdm = ?
            pst.setString(1, new String (funcionario.getSenha()));
            pst.setString(2, funcionario.getCpf());
            
            
            pst.executeUpdate();
            
            
            /*
             pst = conexao.prepareStatement(sql);
            pst.setString(1,txtUsuario2.getText());
            pst.setString(2,new String (txtSenha2.getPassword()));
            pst.setString(3,txtAdm.getText());
            */
       
       
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Erro mudar senha funcionario:"+e.getMessage());
       
       
       }
       
       
        
    }     
       
       
   
    
}
    
    
    

