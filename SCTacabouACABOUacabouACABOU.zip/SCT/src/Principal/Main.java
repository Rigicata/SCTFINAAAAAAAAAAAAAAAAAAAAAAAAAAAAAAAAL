/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import ControllerMaster.ControllerMaster;
import java.awt.event.MouseAdapter;
import java.sql.Connection;
import javax.swing.JFrame;
import model.Conexao;
import views.Principal.TelaInicialVIEW;

/**
 *
 * @author aluno
 */
public class Main extends MouseAdapter{
   public static void main (String [] args) {
       Conexao c = new Conexao();
      
       
       TelaInicialVIEW TELAINICIAL = new TelaInicialVIEW();
       TELAINICIAL.setVisible(true);
       ControllerMaster CM = new ControllerMaster(TELAINICIAL);
       
       
           
       
       
       
       
   }
    
}
